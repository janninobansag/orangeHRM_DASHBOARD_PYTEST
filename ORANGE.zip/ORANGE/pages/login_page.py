from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException
import time


class LoginPage:
    def __init__(self, driver):
        self.driver = driver
        self.wait = WebDriverWait(driver, 20)

        # URL
        self.login_url = "https://opensource-demo.orangehrmlive.com/web/index.php/auth/login"

        # Locators
        self.username_field = (By.NAME, "username")
        self.password_field = (By.NAME, "password")
        self.login_button = (By.CSS_SELECTOR, "button[type='submit']")
        self.error_message = (By.CSS_SELECTOR, ".oxd-alert-content")
        self.dashboard_header = (By.XPATH, "//h6[text()='Dashboard']")

        # Alternative locators
        self.username_field_alt = (By.CSS_SELECTOR, "input[name='username']")
        self.password_field_alt = (By.CSS_SELECTOR, "input[name='password']")
        self.login_button_alt = (By.XPATH, "//button[@type='submit']")

    def navigate_to_login(self):
        """Navigate to the login page"""
        self.driver.get(self.login_url)
        # Wait for page to load
        try:
            self.wait.until(EC.presence_of_element_located(self.username_field))
        except TimeoutException:
            print("Login page did not load properly")

    def enter_username(self, username):
        """Enter username in the username field"""
        try:
            element = self.wait.until(EC.visibility_of_element_located(self.username_field))
            element.clear()
            element.send_keys(username)
        except TimeoutException:
            # Try alternative locator
            element = self.wait.until(EC.visibility_of_element_located(self.username_field_alt))
            element.clear()
            element.send_keys(username)

    def enter_password(self, password):
        """Enter password in the password field"""
        try:
            element = self.wait.until(EC.visibility_of_element_located(self.password_field))
            element.clear()
            element.send_keys(password)
        except TimeoutException:
            # Try alternative locator
            element = self.wait.until(EC.visibility_of_element_located(self.password_field_alt))
            element.clear()
            element.send_keys(password)

    def click_login(self):
        """Click the login button"""
        try:
            element = self.wait.until(EC.element_to_be_clickable(self.login_button))
            element.click()
            time.sleep(2)  # Wait for response
        except TimeoutException:
            # Try alternative locator
            element = self.wait.until(EC.element_to_be_clickable(self.login_button_alt))
            element.click()
            time.sleep(2)

    def login(self, username, password):
        """Complete login process"""
        self.enter_username(username)
        self.enter_password(password)
        self.click_login()

    def get_error_message(self):
        """Get error message text if displayed"""
        try:
            element = self.wait.until(EC.visibility_of_element_located(self.error_message))
            return element.text
        except TimeoutException:
            return None

    def is_dashboard_displayed(self):
        """Check if user is redirected to dashboard after login"""
        try:
            self.wait.until(EC.visibility_of_element_located(self.dashboard_header))
            return True
        except TimeoutException:
            return False

    def is_login_page_displayed(self):
        """Check if login page is displayed"""
        try:
            self.wait.until(EC.visibility_of_element_located(self.username_field))
            return True
        except TimeoutException:
            return False

    def get_current_url(self):
        """Get current page URL"""
        return self.driver.current_url