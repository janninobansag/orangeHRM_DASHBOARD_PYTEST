**OrangeHRM Test Automation Project**
---Project Overview---
This project implements automated testing for the OrangeHRM demo application using Selenium WebDriver 
with Python and Pytest framework. The test suite covers login functionality and dashboard features using 
the Page Object Model (POM) design pattern.

**Table of Contents**

-Test Scope & Objectives
-Project Structure
-Technologies & Tools
-Installation & Setup
-Test Execution
-Test Cases
-Reporting
-Best Practices


**Test Scope & Objectives**
---Scope---

-Application Under Test: OrangeHRM Demo (https://opensource-demo.orangehrmlive.com/)
Modules Covered:

-Login functionality
-Dashboard page verification
-Navigation menu testing
-Widget display validation



**Objectives**

1. Verify login functionality with valid and invalid credentials
2. Validate dashboard page elements and widgets
3. Test navigation across different modules
4. Ensure UI elements are displayed correctly
5. Implement reliable and maintainable test automation

**Tools & Framework**

1. Automation Tool: Selenium WebDriver
2. Programming Language: Python 3.14
3. Testing Framework: Pytest
4. Design Pattern: Page Object Model (POM)
5. Browser: Chrome (with WebDriver Manager)

**Environment**

1. OS: Windows/Linux/Mac
2. Python Version: 3.14
3. Browser: Chrome (latest)

**Assumptions**

1. Stable internet connection available
2. OrangeHRM demo site is accessible
3. Default credentials remain: Admin/admin123

**Constraints**

1. Tests run on Chrome browser only
2. Requires active internet connection
3. Dependent on OrangeHRM demo site availability

**Project Structure**

ORANGE/
│
├── pages/
│   ├── login_page.py           # Login page object model
│   └── dashboard_page.py       # Dashboard page object model
│
├── tests/
│   ├── test_login.py          # Login test cases
│   └── test_dashboard.py      # Dashboard test cases
│
├── .idea/                      # PyCharm IDE configuration
├── .pytest_cache/             # Pytest cache directory
├── main.py                    # Main entry point (if needed)
└── README.md                  # This file

**Installation & Setup**
---Prerequisites---

Python 3.14 or higher installed
pip package manager
Chrome browser installed
IDE (PyCharm recommended)

**Step 1: Clone/Download the Project**
__________________________
git clone <repository-url>
cd ORANGE
___________________________

**Step 2: Create Virtual Environment (Recommended)**
___________________________
# Windows
python -m venv venv
venv\Scripts\activate

# Linux/Mac
python3 -m venv venv
source venv/bin/activate
___________________________

**Step 3: Install Dependencies**
___________________________
pip install selenium
pip install pytest
pip install webdriver-manager
___________________________


**Test Execution**
___________________________
pytest tests/
___________________________


**Run Specific Test File**
___________________________
# Run login tests only
pytest tests/test_login.py

# Run dashboard tests only
pytest tests/test_dashboard.py
___________________________

**Run Specific Test Case**
__________________________
pytest tests/test_login.py::TestLogin::test_successful_login
___________________________


**Run Tests with Verbose Output**

----------------------------
pytest tests/ -v
----------------------------


**Run Tests with Detailed Logging**
---------------------------
pytest tests/ -v -s
---------------------------



**Run Parameterized Tests Only**
______________________________
pytest tests/test_dashboard.py -k "test_individual_widget_display"
_______________________________


Run Tests with HTML Report
___________________________
# Install pytest-html first
pip install pytest-html

# Run with HTML report
py -m pytest -v --html=report.html --self-contained-html
________________________________


**Test Cases**
Login Module Test Cases
TC001: Successful Login

Priority: High
Steps:

Navigate to login page
Enter username: "Admin"
Enter password: "admin123"
Click login button


Expected Result: User redirected to dashboard

****TC002: Invalid Username****

Priority: High
Steps:

Navigate to login page
Enter username: "InvalidUser"
Enter password: "admin123"
Click login button


Expected Result: Error message displayed


****TC003: Invalid Password****

Priority: High
Steps:

Navigate to login page
Enter username: "Admin"
Enter password: "wrongpass"
Click login button


Expected Result: Error message displayed

****TC004: Empty Credentials****

Priority: Medium
Steps:

Navigate to login page
Leave credentials empty
Click login button


Expected Result: Validation message displayed

Dashboard Module Test Cases
****TC005: Dashboard Page Load****

Priority: High
Description: Verify dashboard loads successfully after login

****TC006: Dashboard Widgets Display****

Priority: High
Widgets Verified:

Time at Work
My Actions
Quick Launch
Buzz Latest Posts
Employees on Leave Today
Employee Distribution by Sub Unit



****TC007: Sidebar Navigation****

Priority: High
Modules Tested:

Admin
PIM
Leave
Time
Recruitment
Performance
Directory
Buzz



****TC008: User Dropdown Functionality****

Priority: Medium
Description: Verify user dropdown works correctly




Reporting
Pytest Built-in Reporting
Pytest provides detailed console output by default:

""""pytest tests/ -v""""

HTML Reports
Generate visual HTML reports:

"""pip install pytest-html"""
"""pytest tests/ --html=report.html --self-contained-html"""

****Best Practices****
1. Page Object Model (POM)

Separate page logic from test logic
Each page has its own class
Locators defined as class variables
Page methods return relevant data

2. Explicit Waits

Using WebDriverWait for dynamic elements
Avoiding implicit waits where possible
Proper timeout configuration

3. Pytest Fixtures

Setup and teardown using fixtures
Proper scope management (function, class, module)
Reusable fixture components

4. Parametrization

Using @pytest.mark.parametrize for data-driven tests
Reduces code duplication
Easy to add new test scenarios

5. Assertions

Clear and meaningful assertions
Detailed assertion messages
Proper expected vs actual comparisons

6. Code Organization

Following pytest naming conventions (test_*.py)
Logical grouping of test cases
Modular and reusable code

7. Error Handling

Try-except blocks where appropriate
Meaningful error messages
Graceful failure handling