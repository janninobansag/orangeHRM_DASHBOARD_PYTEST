import pytest
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from pages.login_page import LoginPage
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


@pytest.fixture(scope="function")
def driver():
    """Setup and teardown for WebDriver"""
    logger.info("Initializing Chrome WebDriver")
    driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()))
    driver.maximize_window()
    driver.implicitly_wait(10)

    yield driver

    logger.info("Closing WebDriver")
    driver.quit()


@pytest.fixture(scope="function")
def login_page(driver):
    """Initialize LoginPage object"""
    page = LoginPage(driver)
    page.navigate_to_login()
    return page


class TestLogin:
    """Test suite for OrangeHRM Login functionality"""

    def test_successful_login(self, login_page):
        """
        Test Case 1: Verify successful login with valid credentials
        Steps:
        1. Navigate to login page
        2. Enter valid username: Admin
        3. Enter valid password: admin123
        4. Click login button
        Expected: User should be redirected to dashboard
        """
        logger.info("Test Case 1: Testing successful login")

        login_page.login("Admin", "admin123")

        assert login_page.is_dashboard_displayed(), "Dashboard should be displayed after successful login"
        logger.info("Test Case 1: PASSED - Login successful")

    def test_invalid_username(self, login_page):
        """
        Test Case 2: Verify login fails with invalid username
        Steps:
        1. Navigate to login page
        2. Enter invalid username: InvalidUser
        3. Enter valid password: admin123
        4. Click login button
        Expected: Error message should be displayed
        """
        logger.info("Test Case 2: Testing login with invalid username")

        login_page.login("InvalidUser", "admin123")

        error_message = login_page.get_error_message()
        assert error_message is not None, "Error message should be displayed"
        assert "Invalid credentials" in error_message, "Error message should indicate invalid credentials"
        logger.info("Test Case 2: PASSED - Invalid username handled correctly")

    def test_invalid_password(self, login_page):
        """
        Test Case 3: Verify login fails with invalid password
        Steps:
        1. Navigate to login page
        2. Enter valid username: Admin
        3. Enter invalid password: wrongpass
        4. Click login button
        Expected: Error message should be displayed
        """
        logger.info("Test Case 3: Testing login with invalid password")

        login_page.login("Admin", "wrongpass")

        error_message = login_page.get_error_message()
        assert error_message is not None, "Error message should be displayed"
        assert "Invalid credentials" in error_message, "Error message should indicate invalid credentials"
        logger.info("Test Case 3: PASSED - Invalid password handled correctly")

    def test_empty_credentials(self, login_page):
        """
        Test Case 4: Verify login fails with empty credentials
        Steps:
        1. Navigate to login page
        2. Leave username field empty
        3. Leave password field empty
        4. Click login button
        Expected: Required field validation should appear
        """
        logger.info("Test Case 4: Testing login with empty credentials")

        login_page.click_login()

        # Check that we're still on login page (not redirected)
        assert not login_page.is_dashboard_displayed(), "Should not redirect to dashboard with empty credentials"
        logger.info("Test Case 4: PASSED - Empty credentials validation working")